package com.redeyesncode.redbet.session

object Constant {
    val PREFERENCES_NAME: String = "PAY2KART_SESSION"
    val USER_LOGIN: String = "USER_LOGIN"
    val BODY_UPDATE_KYC: String = "BODY_UPDATE_KYC"

    val IS_LOGGED_IN:String = "IS_LOGGED_IN"

}